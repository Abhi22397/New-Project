package com.iris.daos;

import java.util.List;

import com.iris.models.User;

public interface UserDao {
	public boolean registerCustomer(User Obj) throws Exception;
	public User validate(String name,String password) throws Exception;
	public List<User> getAllCustomer() throws Exception;
	public boolean delete(int id) throws Exception;
	public User updateForm(int id) throws Exception;
	public boolean update(User Obj) throws Exception;

}
