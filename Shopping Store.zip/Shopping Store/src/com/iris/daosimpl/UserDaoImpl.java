package com.iris.daosimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iris.daos.UserDao;
import com.iris.models.User;
import com.iris.utility.ConnectionProvider;

public class UserDaoImpl implements  UserDao {
	Connection conn=ConnectionProvider.getConnection();
	@Override
	public boolean registerCustomer(User Obj) throws Exception {
		PreparedStatement pr=conn.prepareStatement("insert into User1 values (id.nextval,?,?,?,?,?,'Customer')");
		pr.setString(1,Obj.getName());
		pr.setString(2,Obj.getPassword());
		pr.setString(3,Obj.getGender());
		pr.setString(4,Obj.getEmailId());
		pr.setString(5,Obj.getCity());
		int i=pr.executeUpdate();
		if(i!=0) {
			return true;
		}
			return false;
	}

	@Override
	public User validate(String name, String password) throws Exception {
		PreparedStatement pr=conn.prepareStatement("select * from User1 where name=? and password=?");
		pr.setString(1, name);
		pr.setString(2, password);
		ResultSet r=pr.executeQuery();
		if(r.next())
		{
			User Obj=new User();
			Obj.setId(r.getInt(1));
			Obj.setName(r.getString(2));
			Obj.setPassword(r.getString(3));
			Obj.setGender(r.getString(4));
			Obj.setEmailId(r.getString(5));
			Obj.setCity(r.getString(6));
			Obj.setRole(r.getString(7));
			return Obj;
		}
		return null;
	}

	@Override
	public List<User> getAllCustomer() throws Exception {
	    List<User> cust=new ArrayList<>(); 
	    PreparedStatement pr=conn.prepareStatement("select * from User1 where role='Customer'");
	 ResultSet r=pr.executeQuery();
	 while(r.next())
		{
			User Obj=new User();
			Obj.setId(r.getInt(1));
			Obj.setName(r.getString(2));
			Obj.setPassword(r.getString(3));
			Obj.setGender(r.getString(4));
			Obj.setEmailId(r.getString(5));
			Obj.setCity(r.getString(6));
			Obj.setRole(r.getString(7));
			cust.add(Obj);
		}
			return cust;
	}

	@Override
	public boolean delete(int id) throws Exception {
		PreparedStatement pr=conn.prepareStatement("delete from User1 where id=?");
		pr.setInt(1, id);
		int i=pr.executeUpdate();
		if(i!=0)
		{
			return true;
		}
		return false;
	}

	@Override
	public User updateForm(int id) throws Exception {
		PreparedStatement pr=conn.prepareStatement("select * from User1 where id=?");
		pr.setInt(1, id);
		ResultSet r=pr.executeQuery();
		if(r.next())
		{
			User Obj=new User();
			Obj.setId(r.getInt(1));
			Obj.setName(r.getString(2));
			Obj.setPassword(r.getString(3));
			Obj.setGender(r.getString(4));
			Obj.setEmailId(r.getString(5));
			Obj.setCity(r.getString(6));
			Obj.setRole(r.getString(7));
			return Obj;
		}
		return null;
	}

	@Override
	public boolean update(User Obj) throws Exception {
		PreparedStatement ps=conn.prepareStatement("update User1 set name=?,password=?,gender=?,emailId=?,city=?where Id=? ");
		ps.setString(1, Obj.getName());
		ps.setString(2, Obj.getPassword());
		ps.setString(3, Obj.getGender());
		ps.setString(4, Obj.getEmailId());
		ps.setString(5, Obj.getCity());
		ps.setInt(6, Obj.getId());
		int i=ps.executeUpdate();
		if(i!=0)
		{
			return true;
		}
		
		return false;
	}

}
