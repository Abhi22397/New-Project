package com.iris.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.daos.UserDao;
import com.iris.daosimpl.UserDaoImpl;
import com.iris.models.User;


/**
 * Servlet implementation class AllCustDetail
 */
@WebServlet("/AllCustDetail")
public class AllCustDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllCustDetail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		List<User> Obj=new ArrayList<>();
		UserDao dObj=new UserDaoImpl();
		try {
			Obj=dObj.getAllCustomer();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		if(Obj!=null)
		{ request.setAttribute("c", Obj);
			RequestDispatcher rd=request.getRequestDispatcher("GetAllUser.jsp");
			rd.forward(request, response);
		}
		else
			
		{
			out.println("Either problem in server connection Or no data exist in database");
			RequestDispatcher rd=request.getRequestDispatcher("Admin.jsp");
			rd.include(request, response);
		}
		
	}

}
