package com.iris.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.iris.daos.UserDao;
import com.iris.daosimpl.UserDaoImpl;
import com.iris.models.User;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		UserDao dObj=new UserDaoImpl();
		User Obj=new User();
		
		Obj.setName(request.getParameter("name"));
		Obj.setPassword(request.getParameter("password"));
		Obj.setGender(request.getParameter("gender"));
		Obj.setEmailId(request.getParameter("emailId"));
		Obj.setCity(request.getParameter("city"));
		boolean a=false;
		try {
			a=dObj.registerCustomer(Obj);
		} catch (Exception e) {
			// TODO: handle exception
		}
		if(a==true)
		{
			RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
			rd.forward(request, response);
		}
		else
		{
			out.println("U Have Given Wrong Credential");
			RequestDispatcher rs=request.getRequestDispatcher("Registration.jsp");
			rs.forward(request, response);
		}
	}

	}


